
Reg_CNDC <- function(p_train, output=ncol(p_train), t_factor){
  nfolds <- 5
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(!output%in%(1:ncol(p_train))){
    stop("output column out of range")
  }
  
  names(p_train)[output] <- "output"
  if(any(names(p_train)[-output]=="output")){
    v <- names(p_train)[-output]
    v[v=="output"] <- paste("outputss",1:sum(v=="output"),sep="")
    names(p_train)[-output] <- v
  }
  
  folds <- as.list(crossv_kfold(p_train, 5))
  # votes <- integer(nrow(p_train))
  votes <- as.data.frame(matrix(NA, nrow = nrow(p_train), ncol = nfolds))
  preds <- as.data.frame(matrix(NA, nrow = nrow(p_train), ncol = nfolds))
  models <- c("SVM", "NN", "LR", "RF", "NNET")
  
  for(i in 1:nfolds){
    for(kk in 1:length(models)){
      ml <- models[kk]
      votes[folds$test[[i]]$idx,kk] <- testing_CNDC(alg = ml, train.fold = p_train[folds$train[[i]]$idx,],test.fold = p_train[folds$test[[i]]$idx,],output = output,t_factor = t_factor, returns = "votes")
      preds[folds$test[[i]]$idx,kk] <- testing_CNDC(alg = ml, train.fold = p_train[folds$train[[i]]$idx,],test.fold = p_train[folds$test[[i]]$idx,],output = output,t_factor = t_factor, returns = "predictions")  
    }
  }
  
  idx.WN <- which(rowSums(!votes)>=3&rowSums(!votes)<5)
  idx.SN <- which(rowSums(!votes)==5)
  
  Weak.Noise <- idx.WN[which(forecast(prediccion = rowMeans(preds[idx.WN,]),real = p_train[idx.WN,"output"],NS = t_factor))]
  Strong.Noise <- idx.SN[which(!forecast(prediccion = rowMeans(preds[idx.SN,]),real = p_train[idx.SN,"output"],NS = t_factor))]
  
  noise <- c(Weak.Noise, Strong.Noise)
  
  DC.data <- FNN::get.knn(data = p_train[,-ncol(p_train)],  k = 10, algorithm = "brute")$nn.dist	
  DC.pred <- FNN::get.knn(data = preds[,-ncol(preds)],  k = 10, algorithm = "brute")$nn.dist	
  
  remIdx <- noise[which(!forecast(prediccion = rowMeans(DC.pred[noise,]),real = rowMeans(DC.data[noise,]),NS = t_factor))]
  
  message(length(remIdx), " -- noisy instances removed \n")
  ##### Building the 'filter' object ###########
  if(length(remIdx)>0){
    cleanData <- p_train[-remIdx,]
  }else{cleanData <- p_train}
  
  return(cleanData)
}

testing_CNDC <- function(alg, train.fold, test.fold, output, t_factor, returns){
  
  if(!returns%in%c("predictions","votes")){message("Must introduce return -- votes or predictions")
    break}
  formu <- as.formula(paste(names(train.fold)[output],"~.",sep = ""))
  if(alg=="SVM"){
    svm.model <- e1071::svm(x = train.fold[,-output], y = train.fold[,output], type = "eps-regression", kernel = "radial")
    pred <- predict(svm.model, test.fold[,-output])
    out <- forecast(prediccion = pred,real = test.fold[,output],NS = t_factor)
  }
  if(alg=="NN"){
    pred <- FNN::knn.reg(train = train.fold[,-output],test = test.fold[,-output],y = train.fold[,output],k = 10, algorithm=c("brute"))$pred
    out <- forecast(prediccion = pred,real = test.fold[,output],NS = t_factor)
  }
  if(alg=="RF"){
    rf.model <- randomForest(train.fold[,-output], y=train.fold[,output],  xtest=NULL, ytest=NULL, ntree=500)
    pred <- predict(rf.model, test.fold[,-output])
    out <- forecast(prediccion = pred,real = test.fold[,output],NS = t_factor)
  }
  if(alg=="LR"){

    rl.model <- lm(formula = formu, data = train.fold)
    pred <- predict(rl.model, test.fold[,-output])
    out <- forecast(prediccion = pred, real = test.fold[,output],NS = t_factor)
  }
  if(alg=="NNET"){
    nnet.model <- nnet::nnet(formu, train.fold, size=10, linout=TRUE, MaxNWts=ncol(train.fold)^3, maxit=30,trace=F)
    pred <- predict(nnet.model, test.fold[,-output], type="raw")
    out <- forecast(prediccion = pred, real = test.fold[,output],NS = t_factor)
  }
  if(returns=="votes"){return(out)}
  if(returns=="predictions"){return(pred)}
}


