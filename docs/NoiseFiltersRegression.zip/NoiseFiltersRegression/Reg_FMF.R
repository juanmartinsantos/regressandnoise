
Ens_filters <- function(p_train, consensus=FALSE, output=ncol(p_train), t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(!output%in%(1:ncol(p_train))){
    stop("output column out of range")
  }
  
  names(p_train)[output] <- "output"
  if(any(names(p_train)[-output]=="output")){
    v <- names(p_train)[-output]
    v[v=="output"] <- paste("outputss",1:sum(v=="output"),sep="")
    names(p_train)[-output] <- v
  }
  
  if(consensus){
    majThreshold <- 3
  }else{
    majThreshold <- 2}
  
  votes <- as.data.frame(matrix(NA, nrow = nrow(p_train), ncol = 3))
  
  predictions.AENN <- Reg_AENN(p_train = p_train,k=5, t_factor = t_factor)
  votes[,1] <- rownames(p_train)%in%rownames(predictions.AENN)
  predictions.HARF <- Reg_hybridRepairFilter(p_train = p_train, t_factor = t_factor)
  votes[,2] <- rownames(p_train)%in%rownames(predictions.HARF)
  predictions.DF <- Reg_dynamicCF(p_train = p_train, t_factor = t_factor)
  votes[,3] <- rownames(p_train)%in%rownames(predictions.DF)
  
  remIdx <- which(rowSums(votes)<majThreshold)
  
  message(length(remIdx), " -- noisy instances removed \n")
  ##### Building the 'filter' object ###########
  if(length(remIdx)>0){
    cleanData <- p_train[-remIdx,]
  }else{cleanData <- p_train}

  return(cleanData)
}
