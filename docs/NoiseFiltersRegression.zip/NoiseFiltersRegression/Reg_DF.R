

Reg_dynamicCF <- function(p_train, nfolds = 10, consensus = FALSE, m = 3, t_factor){
  if(m<1 || m>9){
    stop("parameter m must be set between 1 and 9")
  }
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <-  ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  if(consensus){
    threshold <- m
  }else{
    threshold <- floor(m/2)+1
  }
  
  predictions <- matrix(nrow=nrow(p_train), ncol=9)
  predictions[,1:9] <- sapply(1:9,function(key){testing(key,p_train,p_train,output,t_factor)})
  ensembleInds <- order(colSums(predictions),decreasing=TRUE)[1:m]
  v <- c("SVM","KNN3","KNN5","KNN9","CART","GBM","RandomForest","LM","MultilayerPerceptron")
  extraInf <- paste(m,"selected model:",paste(v[ensembleInds],collapse=" "))
  
  folds <- as.list(crossv_kfold(p_train, nfolds))
  votes <- integer(nrow(p_train))
  for(i in 1:nfolds){
    votes[folds$test[[i]]$idx] <- m-rowSums(sapply(ensembleInds,function(ind){testing(ind,p_train[folds$train[[i]]$idx,],p_train[folds$test[[i]]$idx,],output,t_factor)}))
  }
  cleanIndexes <- which(votes < threshold)
  ##### Building the 'filter' object ###########
  cleanData <- train_out[cleanIndexes,]
  remIdx  <- which(votes>=threshold)

  return(cleanData)
}

testing <- function(key,trainn,test,output,t_factor){
  formu <- as.formula(paste(names(trainn)[output],"~.",sep = ""))
  if(key==1){
    model <- e1071::svm(x = trainn[,-output], y = trainn[,output], type = "eps-regression", kernel = "radial")
    pred <- predict(model, test[,-output])
    out <- forecast(prediccion = pred,real = test[,output],NS = t_factor)
  }
  if(key%in%c(2,3,4) && !identical(trainn,test)){
    pred <- FNN::knn.reg(train = trainn[,-output],test = test[,-output],y = trainn[,output],k = getK(key), algorithm=c("brute"))$pred
    out <- forecast(prediccion = pred,real = test[,output],NS = t_factor)
  }
  
  if(key%in%c(2,3,4) && identical(trainn,test)){
    pred <- sapply(1:nrow(trainn),function(i){FNN::knn.reg(train = trainn[-i,-output],test = test[i,-output],y = trainn[-i,output],k = getK(key), algorithm=c("brute"))$pred})
    out <- forecast(prediccion = pred,real = test[,output],NS = t_factor)
    }
  if(key==5){
    model <- rpart::rpart(formu, trainn)
    pred <- predict(model, test[,-output], type="vector")
    out <- forecast(prediccion = pred,real = test[,output],NS = t_factor)
  }
  if(key==6){
    modelo <- gbm::gbm(formula = formu, distribution = "gaussian", data = trainn,
                       n.trees = 600)
    pred <- predict.gbm(modelo, test[,-output], n.trees = 600)
    out <- forecast(prediccion = pred,real = test[,output],NS = t_factor)
  }
  if(key==7){
    modelo <- randomForest(trainn[,-output], y=trainn[,output],  xtest=NULL, ytest=NULL, ntree=500)
    pred <- predict(modelo, test[,-output])
    out <- forecast(prediccion = pred,real = test[,output],NS = t_factor)
  }
  
  if(key==8){
    model_I <- lm(formula = formu, data = trainn)
    if(length(which(is.na(model_I$coefficients[2:length(model_I$coefficients)])))!= 0){
      model_I <- lm(formula = formu, data = trainn[,-which(is.na(model_I$coefficients[2:length(model_I$coefficients)]))])
    }
    pred <- predict(model_I, test[,-output])
    out <- forecast(prediccion = pred, real = test[,output],NS = t_factor)
  }
  if(key==9){
    rubbish <- utils::capture.output(modelo <- nnet::nnet(formu, trainn, size=10, linout=TRUE, MaxNWts=ncol(trainn)^3))
    preds <- predict(modelo, test[,-output], type="raw")
    out <- forecast(prediccion = preds, real = test[,output],NS = t_factor)
  }
  out
}
getK <- function(k){
  ifelse(k==2,3,ifelse(k==3,5,9))
}

