

Reg_CVCF <- function(p_train, folds_filters=10, cot_factoret_factorus=FALSE, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  formu <- as.formula(paste(names(p_train)[output],"~.",sep = ""))

  if(cot_factoret_factorus){
    threshold <- folds_filters
  }else{
    threshold <- floor(folds_filters/2)+1
  }
  
  folds <- crossv_kfold(p_train, folds_filters)
  
  votes <- vector("integer",nrow(p_train))
  for(i in 1:folds_filters){
    model <- rpart::rpart(formu,p_train[folds$train[[i]]$idx,],method  = "anova")
    pr_rpart <- predict(model,p_train[,-output],type="vector")
    
    parecidos <- !forecast(prediccion = pr_rpart, real = p_train[,output],t_factor)
    votes <- votes+(parecidos)
  }
  message("Summary: ",length(which(votes < threshold))," instances removed")
  ##### Building the 'filter' object ###########
  cleanData <- train_out[votes < threshold,]
  remIdx  <- which(votes>=threshold)

  return(cleanData)
}