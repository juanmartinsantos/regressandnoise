

Reg_EF <- function(p_train, nfolds=4, consensus=TRUE, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  formu <- as.formula(paste(names(p_train)[output],"~.",sep = ""))
  
  if(consensus){
    threshold <- 3
  }else{
    threshold <- 2
  }
  
  folds <- crossv_kfold(p_train, nfolds)
  
  votes <- vector("integer",nrow(p_train))
  for(i in 1:nfolds){
    #C4.5 algorithm predictions and votes
    model <- rpart::rpart(formu,p_train[folds$train[[i]]$idx,],method  = "anova")
    pr_rpart <- predict(model,p_train[folds$test[[i]]$idx,-output],type="vector")
    parecidos_rpart <- !forecast(prediccion = pr_rpart, real = p_train[folds$test[[i]]$idx,output],t_factor)
    votes[folds$test[[i]]$idx] <- votes[folds$test[[i]]$idx]+parecidos_rpart
    
    #1-NN algorithm predictions and votes
    pr_knn <- FNN::knn.reg(train = p_train[folds$train[[i]]$idx,-output], test = p_train[folds$test[[i]]$idx,-output], y = p_train[folds$train[[i]]$idx,output], k = 1, algorithm = "brute")$pred
    parecidos_knn <- !forecast(prediccion = pr_knn, real = p_train[folds$test[[i]]$idx,output],t_factor)
    votes[folds$test[[i]]$idx] <- votes[folds$test[[i]]$idx]+parecidos_knn
    
    #LinearRegression (LDA) algorithm predictions and votes
    model_I <- lm(formula = formu, data = p_train[folds$train[[i]]$idx,])
    if(length(which(is.na(model_I$coefficients[2:length(model_I$coefficients)])))!= 0){
      model_I <- lm(formula = formu, data = p_train[folds$train[[i]]$idx,-which(is.na(model_I$coefficients[2:length(model_I$coefficients)]))])
    }
    pr_lm <- predict(model_I, p_train[folds$test[[i]]$idx,-output])
    options(warn=-1) 
    parecidos_lm <- !forecast(prediccion = pr_lm, real = p_train[folds$test[[i]]$idx,output],t_factor)
    options(warn=1) 
    votes[folds$test[[i]]$idx] <- votes[folds$test[[i]]$idx]+parecidos_lm
    
  }
  message("Summary: ",length(which(votes >= threshold))," instances removed")
  ##### Building the 'filter' object ###########
  cleanData <- train_out[votes < threshold,]

  return(cleanData)
}



