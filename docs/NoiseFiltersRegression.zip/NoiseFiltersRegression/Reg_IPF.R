

Reg_IPF <- function(p_train, nfolds=5, consensus=FALSE, p=0.01, s=3, y=0.5, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  origSize <- nrow(p_train)
  formu <- as.formula(paste(names(p_train)[output],"~.",sep = ""))
  row.names(p_train) <- 1:nrow(p_train)
  
  #setting some thresholds and auxiliary variables
  if(consensus){
    majThreshold <- nfolds
    }else{majThreshold <- floor(nfolds/2)+1}
  stopThreshold <- floor(nrow(p_train)*p)
  KeepOn <- TRUE #will control the while loop
  counter <- 0 #will control how many consecutive times we filter few nosiy data
  countIter <- 0 # counts the total iterations
  Dg <- data.frame() #Dg will store good instances
  
  while(KeepOn){
    countIter <- countIter+1
    VotesGeneral <- vector("integer",nrow(p_train)) #Counter for total votes
    VotesLocal <- vector("integer",nrow(p_train)) #Counter for votes from the base learner built using the particular instance
    
    folds <- as.list(crossv_kfold(p_train, nfolds))
    
    for(i in 1:nfolds){
      model_rpart <- rpart::rpart(formu,p_train[folds$test[[i]]$idx,], method  = "anova")
      pr_rpart <- predict(model_rpart, p_train[,-output], type="vector")
      
      VotesGeneral <- VotesGeneral+!forecast(prediccion = pr_rpart, real = p_train[,output],t_factor)
      VotesLocal[folds$test[[i]]$idx] <- VotesLocal[folds$test[[i]]$idx]+!forecast(prediccion = pr_rpart[folds$test[[i]]$idx], real = p_train[folds$test[[i]]$idx,output],t_factor)
    }
    
    NoisyIndexes <- which((VotesGeneral >= majThreshold) & (VotesLocal==1))
    GoodIndexes <- which(VotesGeneral==0)
    AmountGoodInst <- min(length(NoisyIndexes),round(y*length(GoodIndexes))) #good instances removed must be less than noisy (original paper requirement)
    
    GoodIndexesToKeep <- sample(GoodIndexes, AmountGoodInst, replace = FALSE)
    
    #removing good and noisy instances
    Dg <- rbind(Dg,p_train[GoodIndexesToKeep,])
    if(length(NoisyIndexes)>0){
      p_train <- p_train[-c(NoisyIndexes,GoodIndexesToKeep),]
    }
    #refreshing stopping conditions
    if(length(NoisyIndexes) <= stopThreshold & counter+1==s) KeepOn <- FALSE
    if(length(NoisyIndexes) <= stopThreshold & counter+1<s) counter <- counter+1
    if(length(NoisyIndexes) > stopThreshold) counter <- 0
    
    message("Iteration ", countIter,": ", length(NoisyIndexes), " noisy instances removed \n")
  }
  finalData <- rbind(p_train,Dg)
  ##### Building the 'filter' object ###########
  remIdx  <- setdiff(1:origSize,as.integer(row.names(finalData)))
  cleanData <- train_out[setdiff(1:origSize,remIdx),]

  return(cleanData)
}


