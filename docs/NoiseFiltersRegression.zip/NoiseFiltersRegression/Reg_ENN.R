

Reg_ENN <- function(p_train, k=3, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train) 
  
  nn <- FNN::get.knn(data = p_train[,-output],  k, algorithm = "brute")$nn.index
  
  NS <- rep(0, nrow(p_train))
  for (i in 1:nrow(p_train)){
    mean_out <- mean(p_train[nn[i,],output])
    NS[i] <- abs(p_train[i,output] - mean_out)
  }
  
  idx_NS <- which(NS >= t_factor)
  if(length(idx_NS)== nrow(train_out) | length(idx_NS)==0){
    message("Summary: 0 instances removed")
  } else{
    train_out <- train_out[-idx_NS,]
    message("Summary: ",length(idx_NS)," instances removed")
  }
  
  return(train_out)
}
