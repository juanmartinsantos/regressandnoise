

Reg_C45robustFilter <- function(p_train, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  origSize <- nrow(p_train)
  formu <- as.formula(paste(names(p_train)[output],"~.",sep = ""))
  
  KeepOn <- TRUE
  counter <- 0
  while(KeepOn){
    counter <- counter+1
    model <- rpart::rpart(formu, p_train)
    pr_rpart <- predict(model, p_train[,-output], type="vector")
    IndexesToRemove <- which(forecast(prediccion = pr_rpart, real = p_train[,output],t_factor)==F)
    
    if(length(IndexesToRemove)==0){
      KeepOn <- FALSE
    }else{
      p_train <- p_train[-IndexesToRemove,]
      train_out <- train_out[-IndexesToRemove,]
    }
    message("Iteration ",counter,": ",length(IndexesToRemove)," instances removed")
  }
  message("Summary: ", origSize - nrow(p_train), " instances removed in ", counter, " iterations")
  ##### Building the 'filter' object ###########
  cleanData <- train_out
  
  return(cleanData)
}

