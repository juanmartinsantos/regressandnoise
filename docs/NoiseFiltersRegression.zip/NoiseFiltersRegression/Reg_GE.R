

Reg_GE <- function(p_train, k=5, as.action="remove", t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train 
  p_train <- normalizeData2(p_train)
  
  localTraget <- get.knn(data = p_train[,-output],  k = k-1, algorithm = "brute")$nn.index
  localTraget <- cbind(c(1:nrow(p_train)),localTraget)
  
  localReg <- matrix(NA, nrow(localTraget),ncol(localTraget))
  for (n in 1:nrow(p_train)) {
    localReg[n,] <- forecast(prediccion = p_train[localTraget[n,],output],real = p_train[n,output],t_factor) 
  }
  
  repIdex <- c()
  remiIdx <- c()
  for(v in 1:nrow(localReg)){
    w <- table(localReg[v,])
    
    if(as.action == "repair"){
      if(names(w)[nnet::which.is.max(w)]==F){
        id_false <- localTraget[v,which(localReg[v,]==F)]
        train_out[v,output] <- mean(train_out[id_false,output])
        repIdex <- c(repIdex,v)
      }
    }
    if(as.action == "remove"){
      if(names(w)[nnet::which.is.max(w)]==F){
        train_out <- train_out[-v,]
        remiIdx <- c(remiIdx, v)
      }
    }
  }
  
  if(as.action == "repair"){message("Summary: ", length(repIdex), " instances repair")}
  if(as.action == "remove"){message("Summary: ", length(remiIdx), " instances removed")}

  ##### Building the 'filter' object ###########
  cleanData <- train_out

  return(cleanData)
}


