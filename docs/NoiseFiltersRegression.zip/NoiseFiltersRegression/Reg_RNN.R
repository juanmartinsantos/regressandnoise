

Reg_RNN <- function(p_train, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  firstDif <- which(forecast(prediccion = p_train[,output],real = p_train[1,output], t_factor)==FALSE)[1]
  
  store <- c(1,firstDif)
  grabBag <- setdiff(1:firstDif,store)
  
  for(i in (firstDif+1):nrow(p_train)){
    nn_pred <- FNN::knn.reg(train = p_train[store,-output], test = p_train[i,-output],y = p_train[store,output],k = 1, algorithm=c("brute"))$pred
    nn_predict <- forecast(prediccion = nn_pred, real = p_train[i,output], t_factor)
    if(nn_predict==T){
      grabBag <- c(grabBag,i)
    }else{
      store <- c(store,i)
    }
  }
  
  KeepOn <- TRUE
  while(KeepOn){
    KeepOn <- FALSE
    for(i in grabBag){
      p_nn <- FNN::knn.reg(train = p_train[store,-output], test = p_train[i,-output],y = p_train[store,output],k = 1, algorithm=c("brute"))$pred
      nn_parecido <- forecast(prediccion = p_nn,real = p_train[i,output],t_factor)
      if(nn_parecido==F){
        store <- c(store,i)
        grabBag <- setdiff(grabBag,i)
        KeepOn <- TRUE
      }
    }
  }
  
  for(i in store){
    pd_nn <- FNN::knn.reg(train = p_train[setdiff(store,i),-output], test = p_train[,-output],y = p_train[setdiff(store,i),output],k = 1, algorithm=c("brute"))$pred
    nn_par <- all(forecast(prediccion = pd_nn,real = p_train[,output],t_factor))
    if(nn_par==T){
      store <- setdiff(store,i)
    }
  }
  message("Summary: ",length(grabBag)," instances removed")
  ##### Building the 'filter' object ###########
  remIdp_train  <- setdiff(1:nrow(p_train),sort(store))
  cleanData <- train_out[sort(store),]

  return(cleanData)
}

