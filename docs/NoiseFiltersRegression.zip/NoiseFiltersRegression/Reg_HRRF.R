
Reg_hybridRepairFilter <- function(p_train, consensus = FALSE, t_factor, turn=FALSE){
  
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  
  output  <-  ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  
  formu <- as.formula(paste(names(p_train)[output],"~.",sep = ""))
  row.names(p_train) <- 1:nrow(p_train)
  
  threshold <- ifelse(consensus,4,2)
  KeepOn <- TRUE
  correctClassifs <- 0
  counter <- 1
  while(KeepOn){
    preds <- predictions(trainn=p_train,test=p_train,formu, t_factor = t_factor)
    votesNoise <- rowSums(apply(preds,2,function(v){!forecast(prediccion = v,real = p_train[,output],NS = t_factor)}))
    noiseInds <- which(votesNoise>=threshold)
    
    dataTemp <- p_train[setdiff(1:nrow(p_train),noiseInds),]
    
    predsOriginal <- predictions(trainn=dataTemp,test=train_out,formu,t_factor = t_factor)
    correctClassifsNew <- sum(apply(predsOriginal,2,function(v){forecast(prediccion = v,real = train_out[,output],NS = t_factor)}))
    if(correctClassifsNew<=correctClassifs){
      KeepOn <- FALSE
    }else{
      correctClassifs <- correctClassifsNew
      counter <- counter+1
      p_train <- dataTemp
    }
  }
  
  ##### Building the 'filter' object ###########
  names(p_train) <- names(train_out)
  row.names(p_train) <- attr(train_out,"row.names")[as.integer(row.names(p_train))]
  remIdx <- setdiff(1:nrow(train_out),as.integer(row.names(p_train)))
  cleanData <- train_out[-remIdx,]
  if(turn==T){message("Summary: ",length(remIdx), " instances removed in ", counter, " iterations")}

  return(cleanData)
}

predictions <- function(trainn, test, formu, t_factor){
  out <- matrix(nrow = nrow(test), ncol = 4)
  output <- ncol(trainn)
  ob_train <- trainn[,-output]
  ob_test <- test[,-output]
  
  model_svm <- e1071::svm(x = ob_train, y = trainn[,output], type = "eps-regression", kernel = "radial")
  pred_svm <- predict(model_svm, ob_test)
  out[,1] <- pred_svm

  rubbish <- utils::capture.output(model_net <- nnet::nnet(formu, trainn, size=10, linout=TRUE,  MaxNWts=ncol(trainn)^3))
  pred_net <- predict(model_net, ob_test, type="raw")
  out[,2] <- pred_net

  model_rpart <- rpart::rpart(formu, trainn, method  = "anova")
  pred_rpart <- predict(model_rpart, ob_test, type="vector")
  out[,3] <- pred_rpart
  
  knnPreds <- matrix(nrow = nrow(test),ncol = 3)
  knnPreds[,c(1,2,3)] <- sapply(c(1,3,5),function(k){
    if(dim(trainn)==dim(test) && all(trainn==test)){
      sapply(1:nrow(trainn),function(i){FNN::knn.reg(train = ob_train[-i,],test = ob_test[i,],y = trainn[-i,output],k = k, algorithm=c("brute"))$pred})
    }
    else{
      FNN::knn.reg(train = ob_train, test = ob_test, y = trainn[,output], k = k, algorithm=c("brute"))$pred
    }
  })

  knnParecidos <- matrix(nrow = nrow(test),ncol = 3)
  for(p in 1:nrow(test)){
    knnParecidos[p,] <- forecast(prediccion = knnPreds[p,],real = test[p,output],NS = t_factor)
    if(any(knnParecidos[p,])){out[p,4] <- mean(knnPreds[p,which(knnParecidos[p,]==T)])
    }else{out[p,4] <- mean(knnPreds[p,])}

  }
  
  return(out)
}



