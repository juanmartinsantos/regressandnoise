

Reg_BBNR <- function(p_train, k=3, t_factor){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
   
  pred_nei <- FNN::get.knn(data = p_train[,-output],  k= k, algorithm = "brute")$nn.index
  knnInf <- sapply(1:nrow(p_train),function(i){
    pred_reg <- FNN::knn.reg(train = p_train[-i,-output], test = p_train[i,-output],y = p_train[-i,output], k = k, algorithm = "brute")$pred
    isMisclassified <- forecast(prediccion = pred_reg ,real = p_train[i,output], t_factor)
    nearestNeigh <- setdiff(1:nrow(p_train),i)[pred_nei[i,]]
    c(isMisclassified,nearestNeigh)
  })
  
  isMisclassified <- as.logical(knnInf[1,])
  knnNeigh <- knnInf[-1,]
  
  classifiesWellOther <- lapply(which(!isMisclassified),function(i){
    id_WellOther <- which(forecast(prediccion = p_train[knnNeigh[,i],output], real = p_train[i,output], t_factor)==T)
    knnNeigh[id_WellOther,i]
  })
  coverageSets <- list()
  length(coverageSets) <- nrow(p_train)
  for(i in 1:length(classifiesWellOther)){
    items <- classifiesWellOther[[i]]
    for(j in items){
      coverageSets[[j]] <- c(coverageSets[[j]],i)
    }
  }
  
  misclassifyOther <- lapply(which(isMisclassified),function(i){
    id_Other <- which(forecast(prediccion = p_train[knnNeigh[,i],output], real = p_train[i,output], t_factor)==F)
    knnNeigh[id_Other,i]
  })
  
  ######################## Knowing as solvent the table
  
  toEp_trainamine <- unlist(misclassifyOther)

  toRemove <- integer(0)
  for(i in toEp_trainamine){
    if(!is.null(coverageSets[[i]])){
      training <- p_train[setdiff(1:nrow(p_train),c(toRemove,i)),-output]
      affects_predic <- FNN::knn.reg(train = training, test = p_train[coverageSets[[i]],-output], y = p_train[setdiff(1:nrow(p_train),c(toRemove,i)),output], k = k, algorithm = "brute")$pred
      affectsRemoval <- forecast(prediccion = affects_predic, real = p_train[coverageSets[[i]],output], t_factor)
      
      if(all(affectsRemoval)){
        toRemove <- c(toRemove,i)
      }
    }else{
      toRemove <- c(toRemove,i)}
  }
  
  ##### Building the 'filter' object ###########
  remIdx  <- toRemove
  cleanData <- train_out[setdiff(1:nrow(train_out),remIdx),]

  return(cleanData)
}



