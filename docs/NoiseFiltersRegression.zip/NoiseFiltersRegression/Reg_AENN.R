
Reg_AENN <- function(p_train, k=5, t_factor, turn=FALSE){
  if(!is.data.frame(p_train)){
    stop("data argument must be a data.frame")
  }
  if(any(sapply(p_train,class)!="numeric")){
    stop("all attributes must be numerical")
  }
  
  output <- ncol(p_train)
  train_out <- p_train
  p_train <- normalizeData2(p_train)
  origSize <- nrow(p_train)

  for(n in 1:k){
    
    nn <- get.knn(data = p_train[,-output],  k = n, algorithm = "brute")$nn.index
    
    NS <- rep(0, nrow(p_train))
    for (i in 1:nrow(p_train)){
      mean_out <- mean(p_train[nn[i,],output])
      NS[i] <- abs(p_train[i,output] - mean_out)
    }
    idx_NS <- which(NS >= t_factor)
    
    if(length(idx_NS)==nrow(p_train) | length(idx_NS)==0){
      if(turn==T){message("Summary: 0 instances removed")}
    } else{
      if(turn==T){message("Summary: ",length(idx_NS)," instances removed")}
      p_train <- p_train[-idx_NS,]
      train_out <- train_out[-idx_NS,]
    }
    rm(nn,NS,mean_out,idx_NS)
  }
  if(turn==T){message("Summary: ", origSize - nrow(train_out), " instances removed in ", k, " iterations")}
  
  dataClean <- train_out
  
  return(dataClean)
}

